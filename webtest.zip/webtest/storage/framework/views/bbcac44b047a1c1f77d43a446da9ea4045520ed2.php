<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Story Telling</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link href="/css/main.css" rel = "stylesheet">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
        <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>

<?php $__env->startSection('contents'); ?>



<body>
 
        <div class="banner">
           <div class="left-column">
        <h1><span>Buy, Sell, Read</span> your favourite books with one touch of a button!</h1>
        <h4>Books of any category, ranging from educational to fictional books. <br>We provide the best books for you to read AND listen.</h4>


            <div class = "search-box">
                <img src ="/img/search.png">
                <input type="text">
            </div>
           </div>


           <div class="right-column">
           <img src="img/books.png">
        </div>
        </div>        

    </div>

<section id="section">
<h1>Recommended For You</h1>
<div class="row">

        <div class="column" style="background-color:#aaa;">
                <h2>Column 1</h2>
                <p>Some text..</p>
              </div>
              <div class="column" style="background-color:#bbb;">
                <h2>Column 2</h2>
                <p>Some text..</p>
              </div>
              <div class="column" style="background-color:#ccc;">
                <h2>Column 3</h2>
                <p>Some text..</p>
              </div>
    
    
</div>

</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp Download\htdocs\webtest\resources\views//welcome.blade.php ENDPATH**/ ?>



<?php $__env->startSection("contents"); ?>


<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Story Telling</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link href="css/about.css" rel = "stylesheet">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
        <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
   


        <section> 
                <div class="about">
                    <h1>About the website</h1>
                <h2>This website is created to give you the fullest experience when trying to read a book. <br> 
                    Too tired to read a book out loud? Too boring without the visual imagination that a <br>book should express? <br>
                </h2>
                

                </div>




        </section>


        


        <section id="member">
            <div class="container">
                 <h1> Get To Know Our Members!</h1>
             <div class="row">
                 <div class="col-md-4 profile-pic text-center">
                     <div class="img-box">
                     <img src="/img/jul.jpg" class="img-responsive">
                     <ul> 
                         <a href="#"><li><i class="fab fa-instagram"> @juliorivaldo</i></li></a>
                         <a href="#"><li><li><i class="fab fa-line"> juliorivaldo__</i></li></a>   
                     </ul>  
                     </div>
                 <h2>Julio Rivaldo</h2>
                 <h3>Programmer - Binusian 2023</h3>
                     <p>Single</p>
                 <p> "Saya Jelek tapi Bangga"</p>   
                 </div>
                 <div class="col-md-4 profile-pic text-center">
                     <div class="img-box">
                     <img src="/img/rsz_2aria.jpg" class="img-responsive">
                     <ul> 
                         <a href="#"><li><i class="fab fa-instagram"> @aria_rifqi</i></li></a>
                         <a href="#"><li><i class="fab fa-line"> armymz2018</i></li></a>
                     </ul>  
                     </div>
                 <h2>Aria Rifqi Y.</h2>
                 <h3>Programmer - Binusian 2023</h3>
                     <p>Single</p>
                 <p>"Being Lazy is great... you create an easy path from a difficult situation."</p>
                 </div>
                 <div class="col-md-4 profile-pic text-center">
                     <div class="img-box">
                     <img src="/img/rsz_william.jpg" class="img-responsive">
                     <ul> 
                         <a href="#"><li><i class="fab fa-instagram"> @w_channzy</i></li></a>
                         <a href="#"><li><i class="fab fa-line"> williamsilv</i></li></a>
                     </ul>  
                     </div>
                 <h2>William Silvano A</h2>
                 <h3>Programmer - Binusian 2023</h3>
                     <p>Single</p>
                 <p> "If it ain't right, it's left."</p>
                 </div>
             </div>
                 
            </div>
            </section>
        

         
            <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp Download\htdocs\webtest\resources\views/about.blade.php ENDPATH**/ ?>
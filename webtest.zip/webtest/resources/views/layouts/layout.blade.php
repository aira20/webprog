<!DOCTYPE html>


    </head>
    <div class = "top">
        

        <div class= "navbar">
            
            <img src= "img/logo.png">  
        <ul>
            <li><a href ="welcome">Home</a></li>
            <li><a href ="/about">About</a></li>
            <li><a href ="#">Best Seller</a></li>
            <li><a href ="#">Store</a></li>
        </ul>

        <div class ="navbar-icons">
           <a href="/logreg"> <img src="img/acc.png"></a>               
        </div>
    
    </div>

    @yield("contents")
    
       
    </body>
    </html>
    <footer> Copyright 2021 Story Telling Group Project</footer>
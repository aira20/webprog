<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function welcomeView()
    {
        return view('welcome',
        ["title" => "about"]);
    }

    public function aboutView()
    {
        return view('about',
        ["title" => "about"]);
    }

    public function logregView()
    {
        return view('logreg',
        ["title" => "logreg"]);
    }

}
